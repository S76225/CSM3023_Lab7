<%-- 
    Document   : dashboard
    Created on : 20 Jun 2026, 11:52:29?am
    Author     : USER
--%>

<%@ page import="com.lab.bean.StudentBean" %>

<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");

    if (user == null) {
        response.sendRedirect("login.html");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
</head>
<body>
    <h2>Welcome, <%= user.getFullname() %></h2>

    <p>Matric Number: <%= user.getMatricNo() %></p>

    <img src="data:image/jpeg;base64,<%= user.getBase64Image() %>"
         width="160"
         height="160"
         alt="Profile Picture">

    <br><br>

    <a href="UserServlet?action=logout">Logout</a>
    <br><br>

    <a href="UserServlet?action=delete"
       onclick="return confirm('Are you sure you want to delete your account permanently?');">
       Delete Account
    </a>
</body>
</html>